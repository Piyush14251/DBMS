How To Run The Project?
To run this project, you must have installed a virtual server i.e XAMPP on your PC (for Windows). This Online Restaurant Management System in PHP with source code is free to download, Use for educational purposes only!

After Starting Apache and MySQL in XAMPP, follow the following steps.


1st Step: Extract file
2nd Step: Copy the main project folder
3rd Step: Paste in xampp/htdocs/

Now Connecting Database

4th Step: Open a browser and go to URL “http://localhost/phpmyadmin/”
5th Step: Then, click on the databases tab
6th Step: Create a database naming “mishtidb” and then click on the import tab
7th Step: Click on browse file and select “mishtidb.sql” file which is inside the “RestoGirls” folder
8th Step: Click on go.

After Creating Database,

9th Step: Open a browser and go to URL “http://localhost/Online-Food-Order/”

For the admin section go to “http://localhost/Online-Food-Order/managerlogin.php” For the project demo, you have a look at the video below:
